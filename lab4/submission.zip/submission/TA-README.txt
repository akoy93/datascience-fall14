Note to the TA:

Sorry the PDF file is so huge. Data Wrangler gave me some really long scripts. I've included all my scripts/output/screenshots in folders labeled "part1", "part2", and "part3", which will probably be easier to look at than the PDF file.

Thanks,
Albert Koy