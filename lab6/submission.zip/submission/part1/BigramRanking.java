package org.myorg;

import java.io.IOException;
import java.util.*;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;


public class BigramRanking {

	public static class Map extends MapReduceBase implements Mapper < LongWritable, Text, Text, Text > {
		private final static IntWritable one = new IntWritable(1);
		private Text bigram = new Text();
		private Text word1 = new Text();
		private Text word2 = new Text();

		public void map(LongWritable key, Text value, OutputCollector output, Reporter reporter) throws IOException {
			String line = value.toString();
			String prev;
			String curr;
			Integer count;
			StringTokenizer tokenizer = new StringTokenizer(line);
			if (tokenizer.hasMoreTokens()) {
				prev = tokenizer.nextToken();
				curr = tokenizer.nextToken();
				count = Integer.parseInt(tokenizer.nextToken());

				bigram.set(prev + " " + curr + " " + count);

				word1.set(prev);
				output.collect(word1, bigram);

				word2.set(curr);
				output.collect(word2, bigram);
			}
		}
	}

	public static class Reduce extends MapReduceBase implements Reducer < Text, Text, Text, Text > {
		public void reduce(Text key, Iterator < Text > values, OutputCollector < Text, Text > output, Reporter reporter) throws IOException {
			TreeSet < String > bigrams = new TreeSet < String > (new Comparator < String > () {
				public int compare(String s1, String s2) {
					return Integer.parseInt(s2.substring(s2.lastIndexOf(" ") + 1)) - Integer.parseInt(s1.substring(s1.lastIndexOf(" ") + 1));
				}
			});

			while (values.hasNext()) {
				bigrams.add(values.next().toString());

				if (bigrams.size() > 5) {
					bigrams.remove(bigrams.pollLast());
				}
			}

			for (String b: bigrams) {
				output.collect(key, new Text(b));
			}
		}
	}

	public static void main(String[] args) throws Exception {
		JobConf conf = new JobConf(BigramRanking.class);
		conf.setJobName("bigramranking");

		conf.setOutputKeyClass(Text.class);
		conf.setOutputValueClass(Text.class);

		conf.setMapperClass(Map.class);
		conf.setCombinerClass(Reduce.class);
		conf.setReducerClass(Reduce.class);

		conf.setInputFormat(TextInputFormat.class);
		conf.setOutputFormat(TextOutputFormat.class);

		FileInputFormat.setInputPaths(conf, new Path(args[0]));
		FileOutputFormat.setOutputPath(conf, new Path(args[1]));

		JobClient.runJob(conf);
	}
}
