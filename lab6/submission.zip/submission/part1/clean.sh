#!/bin/bash
rm -rf *_classes
rm *.jar
hadoop fs -rm -r -f bigramcount
hadoop fs -rm -r -f bigramranking
