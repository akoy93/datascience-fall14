#!/bin/bash
javac -classpath ${HADOOP_HOME}/share/hadoop/common/hadoop-common-2.3.0-cdh5.1.2.jar:${HADOOP_HOME}/share/hadoop/mapreduce/hadoop-mapreduce-client-core-2.3.0-cdh5.1.2.jar -d bigramcount_classes BigramCount.java
jar cvf bigramcount.jar -C bigramcount_classes org
hadoop jar bigramcount.jar org.myorg.BigramCount bigramcount/input bigramcount/output
hadoop fs -cat bigramcount/output/part-00000 > bigram_count.txt

javac -classpath ${HADOOP_HOME}/share/hadoop/common/hadoop-common-2.3.0-cdh5.1.2.jar:${HADOOP_HOME}/share/hadoop/mapreduce/hadoop-mapreduce-client-core-2.3.0-cdh5.1.2.jar -d bigramranking_classes BigramRanking.java
jar cvf bigramranking.jar -C bigramranking_classes org
hadoop jar bigramranking.jar org.myorg.BigramRanking bigramcount/output bigramranking/output
hadoop fs -cat bigramranking/output/part-00000 > bigram_ranking.txt

hadoop fs -rm -r -f bigramcount/output
hadoop fs -rm -r -f bigramranking/output



