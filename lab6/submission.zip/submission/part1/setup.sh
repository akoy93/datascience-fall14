#!/bin/bash
mkdir bigramcount_classes
mkdir bigramranking_classes

hadoop fs -mkdir bigramcount
hadoop fs -mkdir bigramcount/input
hadoop fs -put bible+shakes.nopunc bigramcount/input

hadoop fs -mkdir bigramranking
