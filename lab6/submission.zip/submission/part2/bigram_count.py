from pyspark import SparkContext, SparkConf

prev = None

def map_word(word):
  global prev
  if prev is None:
    ret = ((None, word), 1)
  else:
    ret = ((prev, word), 1)

  prev = word
  return ret

def map_bigram(tuple):
  return [(tuple[0][0], (tuple[0], tuple[1])), (tuple[0][1], (tuple[0], tuple[1]))]

def choose_five(tuple):
  return (tuple[0], sorted(tuple[1], key=lambda x: x[1])[-5:][::-1])

conf = SparkConf().setAppName("WordCount").setMaster("local")

sc = SparkContext(conf=conf)

textFile = sc.textFile("bible+shakes.nopunc")

counts = textFile.flatMap(lambda line: line.split(" ")).map(map_word).reduceByKey(lambda a, b: a + b)
ranks = counts.flatMap(map_bigram).combineByKey((lambda x: [x]), (lambda x, y: x + [y]), (lambda x, y: x + y)).map(choose_five)

print ranks.take(100)

ranks.saveAsTextFile("output")
